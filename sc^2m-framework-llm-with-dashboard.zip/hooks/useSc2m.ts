import { useState, useCallback, useRef, useEffect } from 'react';
import { Var0Entry, Var1Entry, Var2Entry, ChatMessage, AppStats, SyntaxStyle, PendingConstraint, PreviousTurnState } from '../types';
import { getChatResponse, generateSc2mAnalysis, summarizeContext } from '../services/geminiService';

// A simple utility to estimate token count
const estimateTokens = (text: string): number => {
    return Math.ceil(text.length / 4);
};

const VAR2_SUMMARIZE_THRESHOLD = 15; // Trigger summarization when var2 has more than 15 constraints

interface UseSc2mProps {
    syntaxStyle: SyntaxStyle;
}

export const useSc2m = ({ syntaxStyle }: UseSc2mProps) => {
    const [turn, setTurn] = useState(0);
    const [var0Log, setVar0Log] = useState<Var0Entry[]>([]);
    const [var1Log, setVar1Log] = useState<Var1Entry[]>([]);
    const [var2Context, setVar2Context] = useState<Var2Entry[]>([]);
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [stats, setStats] = useState<AppStats>({
        turn: 0,
        totalTokensBaseline: 0,
        totalTokensSc2m: 0,
        cumulativeSavings: 'N/A',
    });
    
    const [isQuotaModalOpen, setIsQuotaModalOpen] = useState(false);

    // Using useRef to keep a persistent log for baseline token calculation
    const rawHistoryForBaseline = useRef<string>("");
    const abortControllerRef = useRef<AbortController | null>(null);

    const [messageToProcess, setMessageToProcess] = useState<{ text: string; isEdit: boolean } | null>(null);

    // State to hold the snapshot of the previous turn for the edit functionality
    const [previousTurnState, setPreviousTurnState] = useState<PreviousTurnState | null>(null);

    const addVar2Constraint = useCallback((constraint: string) => {
        if (!constraint.trim()) return;
        const newConstraint: Var2Entry = {
            id: crypto.randomUUID(),
            constraint: constraint.trim(),
            source: 'manual',
            active: true
        };
        setVar2Context(prev => [...prev, newConstraint]);
    }, []);

    const updateVar2Constraint = useCallback((id: string, constraint: string) => {
        setVar2Context(prev => prev.map(c => c.id === id ? { ...c, constraint } : c));
    }, []);

    const deleteVar2Constraint = useCallback((id: string) => {
        setVar2Context(prev => prev.filter(c => c.id !== id));
    }, []);
    
    const toggleVar2Constraint = useCallback((id: string) => {
        setVar2Context(prev => prev.map(c => c.id === id ? { ...c, active: !c.active } : c));
    }, []);
    
    const closeQuotaModal = useCallback(() => {
        setIsQuotaModalOpen(false);
    }, []);

    const resetSession = useCallback(() => {
        setTurn(0);
        setVar0Log([]);
        setVar1Log([]);
        setVar2Context([]);
        setChatHistory([]);
        setStats({
            turn: 0,
            totalTokensBaseline: 0,
            totalTokensSc2m: 0,
            cumulativeSavings: 'N/A',
        });
        rawHistoryForBaseline.current = "";
        setPreviousTurnState(null); // Clear previous turn state
        setMessageToProcess(null);
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
        }
        setIsLoading(false);
        setIsQuotaModalOpen(false);
    }, []);

    const handleConstraintAction = useCallback((turn: number, constraintId: string, action: 'accept' | 'reject') => {
        let acceptedConstraintText: string | null = null;
    
        const updatedVar1Log = var1Log.map(entry => {
            if (entry.turn === turn) {
                const updatedConstraints = entry.new_constraints.map(constraint => {
                    if (constraint.id === constraintId && constraint.status === 'pending') {
                        if (action === 'accept') {
                            acceptedConstraintText = constraint.constraint;
                        }
                        return { ...constraint, status: action === 'accept' ? 'accepted' : 'rejected' };
                    }
                    return constraint;
                });
                return { ...entry, new_constraints: updatedConstraints };
            }
            return entry;
        });
    
        setVar1Log(updatedVar1Log);
    
        if (acceptedConstraintText) {
            const newConstraint: Var2Entry = {
                id: crypto.randomUUID(),
                constraint: acceptedConstraintText,
                source: `turn:${turn}`,
                active: true,
            };
            setVar2Context(prev => [...prev, newConstraint]);
        }
    }, [var1Log]);

     const handleCancelGeneration = useCallback(() => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
        }
    }, []);

    const processMessage = useCallback(async (userInput: string) => {
        setIsLoading(true);
        abortControllerRef.current = new AbortController();
        const { signal } = abortControllerRef.current;
        
        // `turn` here refers to the state *after* any potential revert, and *before* incrementing for the new message.
        const stateForTurn = {
            currentTurn: turn + 1,
            currentVar1Log: var1Log,
            currentVar2Context: var2Context,
            currentStats: stats,
            currentRawHistory: rawHistoryForBaseline.current,
        };

        const userMessage: ChatMessage = { id: `user-${stateForTurn.currentTurn}`, sender: 'user', text: userInput };
        setChatHistory(prev => [...prev, userMessage]);

        try {
            const aiResponseText = await getChatResponse(userInput, stateForTurn.currentVar1Log, stateForTurn.currentVar2Context, syntaxStyle, signal);
            if (signal.aborted) throw new DOMException('Aborted by user', 'AbortError');

            const analysisJson = await generateSc2mAnalysis(userInput, aiResponseText, signal);
            if (signal.aborted) throw new DOMException('Aborted by user', 'AbortError');

            const newVar0Entry: Var0Entry = {
                turn: stateForTurn.currentTurn,
                userInput,
                llmOutputJson: analysisJson,
                llmOutputText: aiResponseText,
            };
            setVar0Log(prev => [...prev, newVar0Entry]);
            
            const newPendingConstraints: PendingConstraint[] = analysisJson.new_constraints.map(c => ({
                id: crypto.randomUUID(),
                constraint: c,
                status: 'pending'
            }));

            const newVar1Entry: Var1Entry = {
                turn: stateForTurn.currentTurn,
                summary: analysisJson.summary,
                context_fidelity_score: analysisJson.context_fidelity_score,
                new_constraints: newPendingConstraints,
            };

            const updatedVar1Log = [...stateForTurn.currentVar1Log, newVar1Entry];
            setVar1Log(updatedVar1Log);
            
            let updatableVar2Context = [...stateForTurn.currentVar2Context];
            if (updatableVar2Context.length > VAR2_SUMMARIZE_THRESHOLD) {
                const summarizedContext = await summarizeContext(updatableVar2Context, signal);
                if (signal.aborted) throw new DOMException('Aborted by user', 'AbortError');
                setVar2Context(summarizedContext);
                updatableVar2Context = summarizedContext;
            }

            const sc2mVar1Context = JSON.stringify(updatedVar1Log);
            const sc2mVar2Context = JSON.stringify(updatableVar2Context);
            const tokensSc2m = estimateTokens(userInput + sc2mVar1Context + sc2mVar2Context);
            
            const fullHistory = stateForTurn.currentRawHistory + `\nUser: ${userInput}\nAI: ${aiResponseText}`;
            const tokensBaseline = estimateTokens(fullHistory);
            rawHistoryForBaseline.current = fullHistory;

            const crf = tokensSc2m > 0 ? tokensBaseline / tokensSc2m : 1;
            
            const newTotalTokensBaseline = stateForTurn.currentStats.totalTokensBaseline + tokensBaseline;
            const newTotalTokensSc2m = stateForTurn.currentStats.totalTokensSc2m + tokensSc2m;
            
            const compressionRatio = newTotalTokensSc2m > 0 
                ? `${(newTotalTokensBaseline / newTotalTokensSc2m).toFixed(2)}x`
                : 'N/A';

            setStats({
                turn: stateForTurn.currentTurn,
                totalTokensBaseline: newTotalTokensBaseline,
                totalTokensSc2m: newTotalTokensSc2m,
                cumulativeSavings: compressionRatio,
            });

            const aiMessage: ChatMessage = {
                id: `ai-${stateForTurn.currentTurn}`,
                sender: 'ai',
                text: aiResponseText.trim(),
                crf: crf,
            };
            setChatHistory(prev => [...prev, aiMessage]);

            setTurn(stateForTurn.currentTurn);

        } catch (error) {
            console.error("Error processing sC2M response:", error);
            if (error instanceof DOMException && error.name === 'AbortError') {
                 console.log("Request was cancelled by the user.");
                 // The user's prompt should remain in the chat history.
                 // The previous problematic line `setChatHistory(prev => prev.slice(0, -1));` is removed.
            } else {
                let errorText = `Sorry, I encountered an error during sC²M processing: ${error instanceof Error ? error.message : 'Unknown error'}. Please check the console.`;

                if (error instanceof Error && (error.message.includes('429') || error.message.toLowerCase().includes('quota'))) {
                    errorText = "API quota exceeded. Please check your billing status to continue.";
                    setIsQuotaModalOpen(true);
                }

                const errorMessage: ChatMessage = {
                    id: `error-${stateForTurn.currentTurn}`,
                    sender: 'ai',
                    text: errorText,
                };
                setChatHistory(prev => [...prev, errorMessage]);
            }
        } finally {
            setIsLoading(false);
            abortControllerRef.current = null;
        }
    }, [turn, var1Log, var2Context, stats, syntaxStyle, chatHistory, rawHistoryForBaseline.current]);

    // This effect now simply reacts to `messageToProcess` and calls `processMessage`
    // The state manipulation (saving/reverting previousTurnState) is handled in the handlers
    useEffect(() => {
        if (messageToProcess) {
            // Use a timeout to ensure all state updates from the handlers (especially for edits)
            // are processed before `processMessage` starts, preventing race conditions.
            setTimeout(() => {
                processMessage(messageToProcess.text);
                setMessageToProcess(null); // Clear message to process after starting processMessage
            }, 0);
        }
    }, [messageToProcess, processMessage]);


    const handleSendMessage = (userInput: string) => {
        // Save the current state BEFORE adding the new user message and initiating processing.
        // This state will be the "previous state" if the user decides to edit *this* message later.
        setPreviousTurnState({
            var2Context: var2Context,
            stats: stats,
            rawHistoryForBaseline: rawHistoryForBaseline.current,
            turn: turn, // The turn number *before* this message is processed
            var0LogLength: var0Log.length,
            var1LogLength: var1Log.length,
            chatHistoryLength: chatHistory.length,
        });
        setMessageToProcess({ text: userInput, isEdit: false });
    };

    const handleEditLastMessage = (userInput: string) => {
        if (!previousTurnState) {
            console.error("Cannot edit: No previous state to restore. This indicates an issue with state saving for the message you are trying to edit.");
            // Optionally, handle this by showing a user-friendly error or preventing the UI button.
            return;
        }

        // It's important that when we revert, we are setting the state for the *turn prior*
        // to the message that was just sent (and is now being edited).
        setVar2Context(previousTurnState.var2Context);
        setStats(previousTurnState.stats);
        rawHistoryForBaseline.current = previousTurnState.rawHistoryForBaseline;
        setTurn(previousTurnState.turn); // Revert turn counter
        
        // Slice logs back to the state *before* the last turn
        setVar0Log(prev => prev.slice(0, previousTurnState.var0LogLength));
        setVar1Log(prev => prev.slice(0, previousTurnState.var1LogLength));
        // Also slice chatHistory, removing the last user and AI messages
        setChatHistory(prev => prev.slice(0, previousTurnState.chatHistoryLength));

        // Now, enqueue the edited message for processing.
        // It will be processed as if it were a brand new message from this reverted state.
        setMessageToProcess({ text: userInput, isEdit: true });
    };

    return {
        var0Log,
        var1Log,
        var2Context,
        chatHistory,
        isLoading,
        handleSendMessage,
        handleEditLastMessage,
        handleCancelGeneration,
        stats,
        addVar2Constraint,
        updateVar2Constraint,
        deleteVar2Constraint,
        toggleVar2Constraint,
        handleConstraintAction,
        isQuotaModalOpen,
        closeQuotaModal,
        resetSession,
    };
};