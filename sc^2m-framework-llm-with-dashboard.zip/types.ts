export interface Var0Entry {
  turn: number;
  userInput: string;
  llmOutputJson: any; 
  llmOutputText: string;
}

export interface PendingConstraint {
  id: string;
  constraint: string;
  status: 'pending' | 'accepted' | 'rejected';
}

export interface Var1Entry {
  turn: number;
  summary: string;
  new_constraints: PendingConstraint[];
  context_fidelity_score: number;
}

export interface Var2Entry {
  id: string;
  constraint: string;
  source: 'manual' | `turn:${number}` | 'summarized';
  active: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  crf?: number;
}

export interface AppStats {
    turn: number;
    totalTokensBaseline: number;
    totalTokensSc2m: number;
    cumulativeSavings: string;
}

export interface Sc2mResponseJson {
    summary: string;
    new_constraints: string[];
    context_fidelity_score: number;
}

export interface PreviousTurnState {
    var2Context: Var2Entry[];
    stats: AppStats;
    rawHistoryForBaseline: string;
    turn: number;
    var0LogLength: number;
    var1LogLength: number;
    chatHistoryLength: number;
}

export type SyntaxStyle = 'markdown' | 'latex';