
import React from 'react';
import { Var1Entry } from '../types';

interface FidelityChartProps {
    data: Var1Entry[];
}

export const FidelityChart: React.FC<FidelityChartProps> = ({ data }) => {
    if (data.length < 2) {
        return (
            <div className="h-40 flex items-center justify-center text-gray-500 text-sm">
                <p>Not enough data to display chart.</p>
            </div>
        );
    }
    
    const width = 300;
    const height = 150;
    const padding = { top: 20, right: 15, bottom: 25, left: 25 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    const turns = data.map(d => d.turn);
    const scores = data.map(d => d.context_fidelity_score);

    const minTurn = Math.min(...turns);
    const maxTurn = Math.max(...turns);
    const minScore = 0.0;
    const maxScore = 1.0;
    
    // Scales
    const xScale = (turn: number) => {
        if (maxTurn === minTurn) return padding.left;
        return padding.left + ((turn - minTurn) / (maxTurn - minTurn)) * chartWidth;
    };
    const yScale = (score: number) => {
        return padding.top + chartHeight - ((score - minScore) / (maxScore - minScore)) * chartHeight;
    };

    const pathData = data.map(d => `${xScale(d.turn)},${yScale(d.context_fidelity_score)}`).join(' L ');
    
    return (
        <div className="w-full p-2 mb-4 bg-gray-900/50 rounded-lg border border-gray-700/50">
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
                <text x={width/2} y={padding.top - 5} textAnchor="middle" fill="#9ca3af" fontSize="12" fontWeight="bold">Context Fidelity</text>
                
                {/* Y Axis Grid Lines & Labels */}
                {[0, 0.25, 0.5, 0.75, 1.0].map(val => (
                    <g key={val}>
                        <line x1={padding.left} y1={yScale(val)} x2={width - padding.right} y2={yScale(val)} stroke="#4b5563" strokeWidth="0.5" />
                        <text x={padding.left - 5} y={yScale(val) + 3} textAnchor="end" fill="#9ca3af" fontSize="8">{val.toFixed(1)}</text>
                    </g>
                ))}

                {/* X Axis Labels */}
                {data.map(d => (
                     <text key={d.turn} x={xScale(d.turn)} y={height - padding.bottom + 15} textAnchor="middle" fill="#9ca3af" fontSize="8">{d.turn}</text>
                ))}
                
                {/* Line Path */}
                <path d={`M ${pathData}`} fill="none" stroke="#22d3ee" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />

                {/* Data Points */}
                {data.map(d => (
                    <circle key={d.turn} cx={xScale(d.turn)} cy={yScale(d.context_fidelity_score)} r="2.5" fill="#22d3ee" stroke="#111827" strokeWidth="1" />
                ))}

            </svg>
        </div>
    );
};
