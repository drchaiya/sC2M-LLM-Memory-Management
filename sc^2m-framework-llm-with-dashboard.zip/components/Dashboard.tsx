
import React from 'react';
import { Var0Entry, Var1Entry, Var2Entry } from '../types';
import { LogCard } from './LogCard';
import { FidelityChart } from './FidelityChart';
import { Var2Editor } from './Var2Editor';
import { Var1LogViewer } from './Var1LogViewer';

interface DashboardProps {
  var0Log: Var0Entry[];
  var1Log: Var1Entry[];
  var2Context: Var2Entry[];
  onAddVar2: (constraint: string) => void;
  onUpdateVar2: (id: string, constraint: string) => void;
  onDeleteVar2: (id: string) => void;
  onToggleVar2: (id: string) => void;
  onConstraintAction: (turn: number, constraintId: string, action: 'accept' | 'reject') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
    var0Log, 
    var1Log, 
    var2Context,
    onAddVar2,
    onUpdateVar2,
    onDeleteVar2,
    onToggleVar2,
    onConstraintAction,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 h-full p-1">
      <LogCard title="var0: Raw Log" subtitle="Immutable audit source" data={var0Log} />
      
      <LogCard title="var1: Set Point Log" subtitle="Structured, immutable audit">
        <div className="flex flex-col h-full">
            <FidelityChart data={var1Log} />
            <Var1LogViewer log={var1Log} onConstraintAction={onConstraintAction} />
        </div>
      </LogCard>

      <LogCard title="var2: Working Context" subtitle="Curated integral store">
        <Var2Editor 
            context={var2Context}
            onAdd={onAddVar2}
            onUpdate={onUpdateVar2}
            onDelete={onDeleteVar2}
            onToggle={onToggleVar2}
        />
      </LogCard>
    </div>
  );
};