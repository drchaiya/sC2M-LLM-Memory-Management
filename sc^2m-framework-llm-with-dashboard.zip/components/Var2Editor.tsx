
import React, { useState } from 'react';
import { Var2Entry } from '../types';
import { EditIcon, SaveIcon, DeleteIcon, AddIcon } from './icons/Icons';

interface Var2EditorProps {
    context: Var2Entry[];
    onAdd: (constraint: string) => void;
    onUpdate: (id: string, constraint: string) => void;
    onDelete: (id: string) => void;
    onToggle: (id: string) => void;
}

const ToggleSwitch: React.FC<{
    checked: boolean;
    onChange: () => void;
    id: string;
}> = ({ checked, onChange, id }) => (
    <label htmlFor={`toggle-${id}`} className="flex items-center cursor-pointer">
        <div className="relative">
            <input id={`toggle-${id}`} type="checkbox" className="sr-only" checked={checked} onChange={onChange} />
            <div className="block bg-gray-600 w-10 h-6 rounded-full"></div>
            <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${checked ? 'transform translate-x-full bg-cyan-400' : ''}`}></div>
        </div>
    </label>
);

const formatSource = (source: Var2Entry['source']) => {
    if (source === 'manual') return 'Manual';
    if (source === 'summarized') return 'Summarized';
    return `Turn ${source.split(':')[1]}`;
};

export const Var2Editor: React.FC<Var2EditorProps> = ({ context, onAdd, onUpdate, onDelete, onToggle }) => {
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editText, setEditText] = useState('');
    const [newConstraint, setNewConstraint] = useState('');

    const handleEdit = (item: Var2Entry) => {
        setEditingId(item.id);
        setEditText(item.constraint);
    };

    const handleSave = (id: string) => {
        if (editText.trim()) {
            onUpdate(id, editText.trim());
        }
        setEditingId(null);
        setEditText('');
    };
    
    const handleAdd = () => {
        if (newConstraint.trim()) {
            onAdd(newConstraint.trim());
            setNewConstraint('');
        }
    };

    return (
        <div className="flex flex-col h-full">
            <div className="flex-grow overflow-y-auto pr-2 space-y-2">
                {context.length > 0 ? (
                    context.map(item => (
                        <div 
                            key={item.id} 
                            className={`bg-gray-800 p-2 rounded-lg border border-gray-700 flex items-start gap-3 group transition-opacity ${!item.active ? 'opacity-50' : ''}`}
                        >
                             <div className="flex-shrink-0 pt-0.5">
                                <ToggleSwitch id={item.id} checked={item.active} onChange={() => onToggle(item.id)} />
                            </div>

                            <div className="flex-grow">
                                {editingId === item.id ? (
                                    <input
                                        type="text"
                                        value={editText}
                                        onChange={(e) => setEditText(e.target.value)}
                                        onKeyDown={(e) => e.key === 'Enter' && handleSave(item.id)}
                                        onBlur={() => handleSave(item.id)}
                                        className="w-full bg-gray-900 text-sm p-1 rounded focus:outline-none focus:ring-2 focus:ring-cyan-500"
                                        autoFocus
                                    />
                                ) : (
                                    <>
                                        <p className={`text-gray-300 text-xs break-words ${!item.active ? 'line-through' : ''}`}>{item.constraint}</p>
                                        <p className="text-gray-500 text-[10px] mt-1">Source: <span className="font-medium">{formatSource(item.source)}</span></p>
                                    </>
                                )}
                            </div>
                           
                            <div className="flex items-center gap-1 flex-shrink-0">
                                {editingId === item.id ? (
                                    <button onClick={() => handleSave(item.id)} className="p-1 text-green-400 hover:bg-gray-700 rounded" aria-label="Save constraint">
                                        <SaveIcon className="w-4 h-4" />
                                    </button>
                                ) : (
                                    <>
                                        <button onClick={() => handleEdit(item)} className="p-1 text-gray-400 hover:text-cyan-400 hover:bg-gray-700 rounded opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Edit constraint">
                                            <EditIcon className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => onDelete(item.id)} className="p-1 text-gray-400 hover:text-red-500 hover:bg-gray-700 rounded opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Delete constraint">
                                            <DeleteIcon className="w-4 h-4" />
                                        </button>
                                    </>
                                )}
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="flex items-center justify-center h-full text-gray-500 text-sm">
                        <p>No working context defined.</p>
                    </div>
                )}
            </div>
            <div className="flex-shrink-0 pt-3 mt-3 border-t border-gray-700">
                 <div className="flex items-center bg-gray-700 rounded-lg p-1">
                    <input
                        type="text"
                        value={newConstraint}
                        onChange={(e) => setNewConstraint(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                        placeholder="Add new constraint..."
                        className="flex-grow bg-transparent text-sm p-1 focus:outline-none placeholder-gray-400"
                    />
                    <button
                        onClick={handleAdd}
                        disabled={!newConstraint.trim()}
                        className="p-2 rounded-md text-white bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
                        aria-label="Add new constraint"
                    >
                        <AddIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>
        </div>
    );
};