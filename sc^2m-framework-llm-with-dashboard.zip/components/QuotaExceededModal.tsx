import React from 'react';
import { AlertTriangleIcon } from './icons/Icons';

interface QuotaExceededModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReset: () => void;
}

export const QuotaExceededModal: React.FC<QuotaExceededModalProps> = ({ isOpen, onClose, onReset }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-gray-800 rounded-xl border border-yellow-500/50 shadow-2xl p-6 w-full max-w-md mx-4 text-center transform transition-all">
        <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-yellow-500/20 mb-4">
            <AlertTriangleIcon className="h-6 w-6 text-yellow-400" aria-hidden="true" />
        </div>
        
        <h3 className="text-lg font-bold text-white mb-2" id="modal-title">
          API Quota Exceeded
        </h3>
        
        <div className="text-sm text-gray-300 space-y-4">
          <p>
            It appears you have reached the free tier usage limit for the Gemini API. Further requests in this session may fail.
          </p>
          <p>
            You can either reset the session to start over (which may work if your quota resets daily) or visit the billing documentation to upgrade your plan.
          </p>
          <a
            href="https://ai.google.dev/gemini-api/docs/billing"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block text-cyan-400 hover:text-cyan-300 hover:underline font-semibold"
          >
            Google AI Billing Documentation
          </a>
        </div>
        
        <div className="mt-6 flex flex-col sm:flex-row-reverse gap-3">
          <button
            type="button"
            className="inline-flex justify-center w-full rounded-md border border-transparent shadow-sm px-4 py-2 bg-cyan-600 text-base font-medium text-white hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500 sm:text-sm"
            onClick={onReset}
          >
            Reset Session
          </button>
           <button
            type="button"
            className="inline-flex justify-center w-full rounded-md border border-gray-600 shadow-sm px-4 py-2 bg-gray-700 text-base font-medium text-gray-200 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-gray-500 sm:text-sm"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};