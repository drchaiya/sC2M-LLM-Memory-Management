
import React from 'react';

interface LogCardProps {
  title: string;
  subtitle: string;
  data?: any[];
  children?: React.ReactNode;
}

export const LogCard: React.FC<LogCardProps> = ({ title, subtitle, data, children }) => {
  return (
    <div className="bg-gray-800/50 rounded-xl border border-gray-700/80 shadow-lg flex flex-col h-full overflow-hidden">
      <div className="p-4 border-b border-gray-700 flex-shrink-0">
        <h2 className="text-lg font-semibold text-white">{title}</h2>
        <p className="text-sm text-gray-400">{subtitle}</p>
      </div>
      <div className="p-4 flex-grow bg-gray-900/20 min-h-0 relative">
        {children ? (
          <div className="absolute inset-0">{children}</div>
        ) : data && data.length > 0 ? (
          <div className="absolute inset-0 overflow-y-auto space-y-4 pr-2 text-sm">
            {data.slice().reverse().map((item, index) => (
              <div key={index} className="bg-gray-800 p-3 rounded-lg border border-gray-700 shadow-inner">
                <pre className="whitespace-pre-wrap break-words font-mono text-gray-300 text-xs">
                  {JSON.stringify(item, null, 2)}
                </pre>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500 text-sm">
            <p>Log is empty.</p>
          </div>
        )}
      </div>
    </div>
  );
};
