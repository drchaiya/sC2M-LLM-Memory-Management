import React from 'react';
import { AppStats } from '../types';
import { BrainCircuit, Sigma, TrendingUp, Zap, ExportIcon } from './icons/Icons';

interface HeaderProps {
    stats: AppStats;
    onExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({ stats, onExport }) => {
    return (
        <header className="flex-shrink-0 bg-gray-900/50 backdrop-blur-sm border-b border-gray-700/50 p-4 shadow-lg">
            <div className="max-w-screen-2xl mx-auto flex justify-between items-center">
                <div className="flex items-center space-x-3">
                    <BrainCircuit className="w-8 h-8 text-cyan-400" />
                    <div>
                        <h1 className="text-xl font-bold text-white">sC²M Framework Dashboard</h1>
                        <p className="text-sm text-gray-400">Systemic Constraint-Compliance Model</p>
                    </div>
                </div>
                 <div className="flex items-center space-x-2 text-sm">
                    <div className="flex items-center space-x-6">
                        <div className="flex items-center space-x-2">
                            <Sigma className="w-5 h-5 text-gray-400" />
                            <div>
                                <p className="text-gray-400">Turn</p>
                                <p className="font-semibold text-white">{stats.turn}</p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <Zap className="w-5 h-5 text-gray-400" />
                            <div>
                                <p className="text-gray-400">Baseline / sC²M Tokens</p>
                                <p className="font-semibold text-white">{stats.totalTokensBaseline} / <span className="text-green-400">{stats.totalTokensSc2m}</span></p>
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <TrendingUp className="w-5 h-5 text-gray-400" />
                            <div>
                                <p className="text-gray-400">Compression Ratio</p>
                                <p className="font-semibold text-green-400">{stats.cumulativeSavings}</p>
                            </div>
                        </div>
                    </div>
                    <button
                        onClick={onExport}
                        className="flex items-center space-x-2 p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 transition-colors"
                        title="Export session data"
                        aria-label="Export session data"
                    >
                        <ExportIcon className="w-5 h-5" />
                        <span className="hidden sm:inline font-medium">Export</span>
                    </button>
                </div>
            </div>
        </header>
    );
};