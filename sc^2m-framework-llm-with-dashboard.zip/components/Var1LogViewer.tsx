import React from 'react';
import { Var1Entry } from '../types';
import { CheckIcon, RejectIcon } from './icons/Icons';

interface Var1LogViewerProps {
    log: Var1Entry[];
    onConstraintAction: (turn: number, constraintId: string, action: 'accept' | 'reject') => void;
}

const ConstraintActions: React.FC<{
    turn: number;
    constraint: Var1Entry['new_constraints'][0];
    onAction: Var1LogViewerProps['onConstraintAction'];
}> = ({ turn, constraint, onAction }) => {
    if (constraint.status === 'pending') {
        return (
            <div className="flex items-center gap-1">
                <button 
                    onClick={() => onAction(turn, constraint.id, 'accept')}
                    className="p-1.5 rounded-full text-gray-400 hover:text-green-400 bg-gray-900/50 hover:bg-green-500/10 transition-colors"
                    title="Accept Constraint"
                    aria-label="Accept Constraint"
                >
                    <CheckIcon className="w-4 h-4" />
                </button>
                <button
                    onClick={() => onAction(turn, constraint.id, 'reject')}
                    className="p-1.5 rounded-full text-gray-400 hover:text-red-500 bg-gray-900/50 hover:bg-red-500/10 transition-colors"
                    title="Reject Constraint"
                    aria-label="Reject Constraint"
                >
                    <RejectIcon className="w-4 h-4" />
                </button>
            </div>
        );
    }
    
    if (constraint.status === 'accepted') {
        return (
            <div className="flex items-center gap-1 text-green-400" title="Accepted">
                <CheckIcon className="w-4 h-4" />
                <span className="text-xs font-medium">Accepted</span>
            </div>
        );
    }

    if (constraint.status === 'rejected') {
        return (
            <div className="flex items-center gap-1 text-red-500" title="Rejected">
                <RejectIcon className="w-4 h-4" />
                <span className="text-xs font-medium">Rejected</span>
            </div>
        );
    }

    return null;
}


export const Var1LogViewer: React.FC<Var1LogViewerProps> = ({ log, onConstraintAction }) => {
    return (
        <div className="flex-grow overflow-y-auto space-y-4 pr-2">
            {log.length > 0 ? (
                log.slice().reverse().map((entry) => (
                    <div key={entry.turn} className="bg-gray-800 p-3 rounded-lg border border-gray-700 shadow-inner text-xs">
                        <div className="flex justify-between items-center mb-2 pb-2 border-b border-gray-700">
                            <p className="font-bold text-white">Turn {entry.turn}</p>
                            <p className="text-gray-400">Fidelity: <span className="font-semibold text-cyan-400">{entry.context_fidelity_score.toFixed(2)}</span></p>
                        </div>
                        <p className="text-gray-300 mb-3"><span className="font-semibold text-gray-400">Summary:</span> {entry.summary}</p>

                        {entry.new_constraints.length > 0 && (
                             <div>
                                <h4 className="text-gray-400 font-semibold mb-2">Suggested Constraints:</h4>
                                <div className="space-y-2">
                                {entry.new_constraints.map(constraint => (
                                    <div 
                                        key={constraint.id} 
                                        className="bg-gray-900/70 p-2 rounded-md border border-gray-700/50 flex justify-between items-center gap-2"
                                    >
                                        <p className={`flex-grow text-gray-300 ${constraint.status === 'rejected' ? 'line-through text-gray-500' : ''}`}>
                                            {constraint.constraint}
                                        </p>
                                        <ConstraintActions turn={entry.turn} constraint={constraint} onAction={onConstraintAction} />
                                    </div>
                                ))}
                                </div>
                             </div>
                        )}
                    </div>
                ))
            ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                    <p>Log is empty.</p>
                </div>
            )}
        </div>
    );
};
