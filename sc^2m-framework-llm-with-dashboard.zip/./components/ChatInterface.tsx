import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, SyntaxStyle } from '../types';
import { SendIcon, UserIcon, BotIcon, CopyIcon, CheckIcon, EditIcon, StopIcon, SaveIcon, SpinnerIcon } from './icons/Icons';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
  onEditLastMessage: (message: string) => void;
  onCancelGeneration: () => void;
  isLoading: boolean;
  syntaxStyle: SyntaxStyle;
  setSyntaxStyle: (style: SyntaxStyle) => void;
}

const renderSimpleMarkdown = (text: string) => {
    // Escape HTML to prevent XSS, but do it carefully
    const escapedText = text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

    // Replace markdown **bold** with <strong>
    const boldedText = escapedText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    return { __html: boldedText };
};


export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
    messages, 
    onSendMessage, 
    onEditLastMessage,
    onCancelGeneration,
    isLoading,
    syntaxStyle,
    setSyntaxStyle,
}) => {
  const [input, setInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto'; // Reset height to shrink when text is deleted
      const scrollHeight = textarea.scrollHeight;
      textarea.style.height = `${scrollHeight}px`; // Set height to scroll height
    }
  }, [input]);

  const handleSend = () => {
    if (input.trim() && !isLoading) {
        if(editingMessage) {
            onEditLastMessage(input.trim());
            setEditingMessage(null);
        } else {
            onSendMessage(input.trim());
        }
        setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        handleSend();
    }
  };


  const handleCopy = (text: string, id: string) => {
    if (copiedId === id) return;
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => {
        setCopiedId(null);
      }, 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
    });
  };

  const handleStartEdit = (message: ChatMessage) => {
      setEditingMessage(message);
      setInput(message.text);
      textareaRef.current?.focus();
  };
  
  const handleCancelEdit = () => {
      setEditingMessage(null);
      setInput('');
  }

  const lastUserMessage = messages.filter(m => m.sender === 'user').pop();

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="p-4 border-b border-gray-700 flex justify-between items-center">
        <h2 className="text-lg font-semibold">Conversation</h2>
        <div className="flex items-center">
          <label htmlFor="syntax-style" className="text-xs text-gray-400 mr-2 font-medium">Syntax</label>
          <select 
            id="syntax-style" 
            value={syntaxStyle} 
            onChange={e => setSyntaxStyle(e.target.value as SyntaxStyle)} 
            className="bg-gray-700 border border-gray-600 text-white text-xs rounded-md focus:ring-cyan-500 focus:border-cyan-500 block w-full p-1"
            >
            <option value="markdown">Markdown</option>
            <option value="latex">LaTeX</option>
          </select>
        </div>
      </div>
      <div className="flex-grow p-4 overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`group flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end relative' : ''}`}> {/* Added relative to parent for absolute positioning */}
            {msg.sender === 'ai' && (
              <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                <BotIcon className="w-5 h-5 text-fuchsia-400" />
              </div>
            )}
            <div className={`relative max-w-md p-3 rounded-xl ${msg.sender === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-fuchsia-700 text-white rounded-bl-none'}`}>
              
              {/* Action buttons for AI messages (only copy, inside bubble, on hover) */}
              {msg.sender === 'ai' && (
                  <div className="absolute top-1.5 right-1.5 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                          onClick={() => handleCopy(msg.text, msg.id)}
                          className={`p-1 rounded-md text-gray-300 hover:text-white bg-fuchsia-800 hover:bg-fuchsia-600 transition-colors`}
                          aria-label="Copy message"
                          disabled={copiedId === msg.id}
                      >
                          {copiedId === msg.id ? (
                          <CheckIcon className="w-4 h-4 text-green-400" />
                          ) : (
                          <CopyIcon className="w-4 h-4" />
                          )}
                      </button>
                  </div>
              )}

              <div className={`text-sm whitespace-pre-wrap ${msg.sender === 'user' ? 'pr-4' : 'pr-6'}`} dangerouslySetInnerHTML={renderSimpleMarkdown(msg.text)} />
              {msg.sender === 'ai' && msg.crf && (
                  <p className="text-xs text-fuchsia-400/80 mt-2 pt-2 border-t border-gray-600">
                      CRF: {msg.crf.toFixed(2)}x
                  </p>
              )}
            </div>
             {msg.sender === 'user' && (
              <>
                {/* Action container for user messages (outside bubble) */}
                <div className="absolute right-12 top-1/2 -translate-y-1/2 flex items-center space-x-1 z-10">
                    {msg.id === lastUserMessage?.id && !isLoading && !editingMessage && (
                        <button
                            onClick={() => handleStartEdit(msg)}
                            className="p-1 rounded-md text-blue-200 hover:text-white bg-blue-700 hover:bg-blue-500 transition-colors"
                            aria-label="Edit message"
                        >
                            <EditIcon className="w-4 h-4" />
                        </button>
                    )}
                    <button
                        onClick={() => handleCopy(msg.text, msg.id)}
                        className={`p-1 rounded-md text-blue-200 hover:text-white bg-blue-700 hover:bg-blue-500 transition-colors ${copiedId === msg.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                        aria-label="Copy message"
                        disabled={copiedId === msg.id}
                    >
                        {copiedId === msg.id ? (
                        <CheckIcon className="w-4 h-4 text-green-400" />
                        ) : (
                        <CopyIcon className="w-4 h-4" />
                        )}
                    </button>
                </div>
                <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <UserIcon className="w-5 h-5 text-blue-300" />
                </div>
              </>
            )}
          </div>
        ))}
         {isLoading && (
            <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                    <BotIcon className="w-5 h-5 text-fuchsia-400" />
                </div>
                <div className="max-w-md p-3 rounded-xl bg-fuchsia-700 rounded-bl-none flex items-center space-x-2 text-fuchsia-300">
                    <SpinnerIcon className="w-4 h-4 animate-spin" />
                    <span className="text-sm font-medium">thinking...</span>
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-gray-700">
        {editingMessage && (
            <div className="text-xs text-gray-400 mb-2 flex justify-between items-center">
                <span>Editing message...</span>
                <button onClick={handleCancelEdit} className="text-cyan-400 hover:underline px-2 py-1 rounded-md hover:bg-gray-700 transition-colors" aria-label="Cancel editing">Cancel</button>
            </div>
        )}
        <div className="flex items-end bg-gray-700 rounded-lg p-1">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            rows={1}
            className="flex-grow bg-transparent text-sm p-2 resize-none focus:outline-none placeholder-gray-400"
            disabled={isLoading}
            style={{ maxHeight: '200px' }}
          />
           {isLoading ? (
            <button
                type="button"
                onClick={onCancelGeneration}
                className="p-2 m-0.5 rounded-md text-gray-300 hover:text-white transition-colors bg-gray-600 hover:bg-red-500"
                aria-label="Stop generation"
                title="Stop generation"
            >
                <StopIcon className="w-5 h-5" />
            </button>
        ) : (
            <button
                type="button"
                onClick={handleSend}
                disabled={!input.trim()}
                className="p-2 m-0.5 rounded-md text-white transition-colors bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
                aria-label={editingMessage ? 'Save changes' : 'Send message'}
            >
                {editingMessage ? <SaveIcon className="w-5 h-5" /> : <SendIcon className="w-5 h-5" />}
            </button>
        )}
        </div>
        <p className="text-center text-xs text-gray-500 pt-2">
            Press <kbd className="px-1.5 py-0.5 font-sans text-xs font-semibold text-gray-400 bg-gray-900 border border-gray-600 rounded-md">Ctrl</kbd> + <kbd className="px-1.5 py-0.5 font-sans text-xs font-semibold text-gray-400 bg-gray-900 border border-gray-600 rounded-md">Enter</kbd> to send.
        </p>
      </div>
    </div>
  );
};