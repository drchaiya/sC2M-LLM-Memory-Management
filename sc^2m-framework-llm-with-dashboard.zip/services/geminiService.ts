import { GoogleGenAI, Chat, Type } from "@google/genai";
import { Sc2mResponseJson, SyntaxStyle, Var1Entry, Var2Entry } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    console.error("Gemini API key is not set in environment variables.");
    throw new Error("Missing Gemini API Key");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

// A persistent chat session for the main conversation
const chat: Chat = ai.chats.create({
    model: 'gemini-2.5-flash',
});

// Function for the main conversational response
export const getChatResponse = async (userInput: string, var1Log: Var1Entry[], var2Context: Var2Entry[], syntaxStyle: SyntaxStyle, signal?: AbortSignal): Promise<string> => {
    // Construct a concise context string for the conversational model
    const latestSummary = var1Log.length > 0 ? var1Log[var1Log.length - 1].summary : "No summary yet.";
    const constraints = var2Context
        .filter(c => c.active)
        .map(c => `- ${c.constraint}`).join('\n');
    
    const formattingInstruction = syntaxStyle === 'latex'
        ? 'IMPORTANT: All your responses must be formatted using LaTeX syntax. Use \\textbf{} for bold, \\textit{} for italics, etc.'
        : 'IMPORTANT: All your responses must be formatted using Markdown.';

    const contextMessage = `
        ${formattingInstruction}

        Current Conversation Summary: ${latestSummary}
        Current constraints to follow:
        ${constraints}
    `;

    // We'll use the persistent chat session, but prepend the latest context.
    const response = await chat.sendMessage({
        message: `${contextMessage}\n\nUser Question: ${userInput}`,
    }, { signal });
    
    return response.text;
};

// Function for the sC²M analysis
export const generateSc2mAnalysis = async (userInput: string, llmOutput: string, signal?: AbortSignal): Promise<Sc2mResponseJson> => {
    const analysisPrompt = `
        As an AI system architect, analyze the following user-AI interaction based on the Systemic Constraint-Compliance Model (sC²M).
        Your task is to provide a structured JSON analysis.

        **Interaction:**
        - User Input: "${userInput}"
        - AI Output: "${llmOutput}"

        **Your Analysis (JSON Object):**
        1.  **summary**: Provide a concise, one-sentence summary of the key information exchanged in this turn.
        2.  **new_constraints**: Identify any new, implicit or explicit constraints, rules, or facts from the interaction that should guide future responses. This MUST be an array of strings. If none, return an empty array.
        3.  **context_fidelity_score**: Rate how well the AI's output adhered to the assumed existing context (on a scale of 0.0 to 1.0). 1.0 is perfect adherence, 0.0 is complete deviation.

        Produce ONLY the JSON object.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: analysisPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    summary: { type: Type.STRING },
                    new_constraints: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    },
                    context_fidelity_score: { type: Type.NUMBER }
                },
                required: ["summary", "new_constraints", "context_fidelity_score"]
            }
        },
        signal,
    });

    try {
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);
        // Basic validation
        if (typeof parsedJson.context_fidelity_score === 'number' && Array.isArray(parsedJson.new_constraints)) {
             return parsedJson as Sc2mResponseJson;
        } else {
            throw new Error("Parsed JSON has incorrect types for analysis fields.");
        }
    } catch (e) {
        console.error("Failed to parse sC²M analysis JSON:", response.text, e);
        // Fallback in case of parsing error
        return {
            summary: "Error parsing analysis.",
            new_constraints: [],
            context_fidelity_score: 0.0
        };
    }
};

// Function for context summarization (anti-windup)
export const summarizeContext = async (var2Context: Var2Entry[], signal?: AbortSignal): Promise<Var2Entry[]> => {
    const constraintsToSummarize = var2Context.map(c => `- ${c.constraint}`).join('\n');
    const summarizationPrompt = `
        Analyze the following list of conversational constraints. Summarize and consolidate them into a smaller, more concise set of equivalent high-level rules.
        The goal is to reduce the number of constraints while preserving their essential meaning.

        **Constraints to Summarize:**
        ${constraintsToSummarize}

        **Your Output (JSON Array of Strings):**
        Return a JSON array containing the new, summarized constraint strings.
        For example: ["Rule 1", "Rule 2", "Another important fact"]

        Produce ONLY the JSON array.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: summarizationPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
            }
        },
        signal,
    });

    try {
        const jsonText = response.text.trim();
        const summarizedConstraints: string[] = JSON.parse(jsonText);
        return summarizedConstraints.map(c => ({
            id: crypto.randomUUID(),
            constraint: c,
            source: 'summarized',
            active: true,
        }));
    } catch (e) {
        console.error("Failed to parse summarized context JSON:", response.text, e);
        // Fallback: return the original context if summarization fails
        return var2Context;
    }
};