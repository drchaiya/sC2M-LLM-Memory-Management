import React, { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { ChatInterface } from './components/ChatInterface';
import { useSc2m } from './hooks/useSc2m';
import { Header } from './components/Header';
import { SyntaxStyle } from './types';
import { QuotaExceededModal } from './components/QuotaExceededModal';

const App: React.FC = () => {
  const [syntaxStyle, setSyntaxStyle] = useState<SyntaxStyle>('markdown');

  const {
    var0Log,
    var1Log,
    var2Context,
    chatHistory,
    isLoading,
    handleSendMessage,
    handleEditLastMessage,
    handleCancelGeneration,
    stats,
    addVar2Constraint,
    updateVar2Constraint,
    deleteVar2Constraint,
    toggleVar2Constraint,
    handleConstraintAction,
    isQuotaModalOpen,
    closeQuotaModal,
    resetSession,
  } = useSc2m({ syntaxStyle });

  const handleExportData = () => {
    const exportData = {
      exportedAt: new Date().toISOString(),
      stats,
      logs: {
        var0_raw: var0Log,
        var1_setPoint: var1Log,
        var2_workingContext: var2Context,
      },
      chatHistory,
    };

    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const date = new Date().toISOString().split('T')[0];
    link.download = `sc2m-session-${date}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-screen font-sans bg-gray-900 text-gray-200 overflow-hidden">
      <Header stats={stats} onExport={handleExportData} />
      <main className="flex-grow grid grid-cols-1 lg:grid-cols-5 gap-4 p-4 min-h-0">
        <div className="col-span-1 lg:col-span-3 h-full min-h-0">
          <Dashboard
            var0Log={var0Log}
            var1Log={var1Log}
            var2Context={var2Context}
            onAddVar2={addVar2Constraint}
            onUpdateVar2={updateVar2Constraint}
            onDeleteVar2={deleteVar2Constraint}
            onToggleVar2={toggleVar2Constraint}
            onConstraintAction={handleConstraintAction}
          />
        </div>
        <div className="col-span-1 lg:col-span-2 h-full flex flex-col bg-gray-800 rounded-xl border border-gray-700 shadow-2xl min-h-0">
          <ChatInterface
            messages={chatHistory}
            onSendMessage={handleSendMessage}
            onEditLastMessage={handleEditLastMessage}
            onCancelGeneration={handleCancelGeneration}
            isLoading={isLoading}
            syntaxStyle={syntaxStyle}
            setSyntaxStyle={setSyntaxStyle}
          />
        </div>
      </main>
      <QuotaExceededModal isOpen={isQuotaModalOpen} onClose={closeQuotaModal} onReset={resetSession} />
    </div>
  );
};

export default App;